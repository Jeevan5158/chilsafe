# Safelytics application

This folder contains the Flask route handlers, rule-based analysis, public-web fetching, database support, page templates and tests.

Use the repository root [README](../../README.md) for current setup and Vercel deployment instructions. See the [deployment review](../../DEPLOYMENT_FIXES.md) for the diagnosed problems and validation results.

The frontend assets live in `public/` at the repository root. Run `python app.py` from that root after installing `requirements.txt`; the local default port is 5004.

History uses SQLite locally, temporary SQLite on Vercel, or PostgreSQL when `DATABASE_URL` is set. The scoring logic and synthetic evaluation fixtures remain in this package.
