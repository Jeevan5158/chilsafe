"""Shared scan history: PostgreSQL, or SQLite on writable local storage."""

from __future__ import annotations

import json
import os
import sqlite3
import tempfile
import threading
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

from .analysis import sanitize_url_for_storage

APP_DIR = Path(__file__).resolve().parent
DEFAULT_DATABASE = APP_DIR / "instance" / "safelytics.sqlite3"
STORAGE_ERRORS = (sqlite3.Error, psycopg.Error, OSError, ValueError)
_initialized = set()
_schema_lock = threading.Lock()


def database_path(path: str | Path | None = None) -> Path:
    default = (
        Path(tempfile.gettempdir()) / "safelytics" / "safelytics.sqlite3"
        if os.environ.get("VERCEL") == "1" else DEFAULT_DATABASE
    )
    return Path(path or os.environ.get("SAFELYTICS_DB_PATH") or default)


def database_target() -> str:
    return os.environ.get("DATABASE_URL") or str(database_path())


def is_postgres(path: str | Path | None = None) -> bool:
    return str(path or database_target()).startswith(("postgres://", "postgresql://"))


def _execute(connection, sql, parameters=()):
    if isinstance(connection, psycopg.Connection):
        sql = sql.replace("?", "%s")
    return connection.execute(sql, parameters)


def _create_schema(connection, postgres: bool) -> None:
    if postgres:
        # Serialize first-time schema creation across serverless instances.
        connection.execute("SELECT pg_advisory_xact_lock(741920261118)")
    id_type = "BIGSERIAL PRIMARY KEY" if postgres else "INTEGER PRIMARY KEY AUTOINCREMENT"
    connection.execute(
            f"""
            CREATE TABLE IF NOT EXISTS scans (
                id {id_type},
                normalized_url TEXT NOT NULL,
                scanned_at TEXT NOT NULL,
                risk_score DOUBLE PRECISION,
                risk_level TEXT NOT NULL,
                component_scores TEXT NOT NULL,
                limitations TEXT NOT NULL,
                scan_json TEXT NOT NULL
            )
            """
    )
    connection.execute(
            "CREATE INDEX IF NOT EXISTS idx_scans_url_time "
            "ON scans(normalized_url, scanned_at DESC)"
    )


@contextmanager
def _connect(path: str | Path | None = None):
    target = str(path or database_target())
    postgres = is_postgres(target)
    if "://" in target and not postgres:
        raise ValueError("DATABASE_URL must be a PostgreSQL connection string.")
    if postgres:
        connection = psycopg.connect(
            target, row_factory=dict_row, connect_timeout=5,
            options="-c statement_timeout=5000 -c lock_timeout=5000",
        )
    else:
        resolved = database_path(target)
        resolved.parent.mkdir(parents=True, exist_ok=True)
        if not resolved.exists():
            _initialized.discard(target)
        connection = sqlite3.connect(resolved, timeout=5)
        connection.row_factory = sqlite3.Row
    try:
        if not postgres:
            connection.execute("PRAGMA busy_timeout = 5000")
            connection.execute("PRAGMA journal_mode = WAL")
        with _schema_lock:
            if target not in _initialized:
                _create_schema(connection, postgres)
                connection.commit()
                _initialized.add(target)
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def initialize_database(path: str | Path | None = None) -> None:
    with _connect(path):
        pass


def _clean_scan_payload(scan: dict) -> dict:
    payload = dict(scan)
    payload["url"] = sanitize_url_for_storage(payload.get("url", ""))
    payload["normalized_url"] = sanitize_url_for_storage(
        payload.get("normalized_url") or payload.get("url", "")
    )
    domain = dict(payload.get("domain") or {})
    if domain.get("final_url"):
        domain["final_url"] = sanitize_url_for_storage(domain["final_url"])
    domain["redirect_chain"] = [
        {
            **item,
            "source": sanitize_url_for_storage(item["source"]),
            "destination": sanitize_url_for_storage(item["destination"]),
        }
        for item in (domain.get("redirect_chain") or [])
    ]
    payload["domain"] = domain
    return payload


def save_scan(scan: dict, path: str | Path | None = None) -> int:
    """Insert a scan, redacting common secret-like query values first."""
    payload = _clean_scan_payload(scan)
    timestamp = datetime.now(timezone.utc).isoformat(timespec="seconds")
    payload["scanned_at"] = timestamp
    components = payload.get("component_scores") or {}
    with _connect(path) as connection:
        cursor = _execute(connection,
            """
            INSERT INTO scans (
                normalized_url, scanned_at, risk_score, risk_level,
                component_scores, limitations, scan_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?) RETURNING id
            """,
            (
                payload["normalized_url"],
                timestamp,
                payload.get("risk_score"),
                payload.get("risk_level", "Unknown"),
                json.dumps(components, ensure_ascii=False),
                json.dumps(payload.get("limitations", []), ensure_ascii=False),
                json.dumps(payload, ensure_ascii=False),
            ),
        )
        return int(cursor.fetchone()["id"])


def _row_to_scan(row: sqlite3.Row) -> dict:
    scan = json.loads(row["scan_json"])
    scan["id"] = row["id"]
    scan["scanned_at"] = row["scanned_at"]
    scan["normalized_url"] = row["normalized_url"]
    scan["risk_score"] = row["risk_score"]
    scan["risk_level"] = row["risk_level"]
    scan["component_scores"] = json.loads(row["component_scores"])
    scan["limitations"] = json.loads(row["limitations"])
    return scan


def get_scan(scan_id: int, path: str | Path | None = None) -> dict | None:
    with _connect(path) as connection:
        row = _execute(connection,
            "SELECT * FROM scans WHERE id = ?", (scan_id,)
        ).fetchone()
    return _row_to_scan(row) if row else None


def list_scans(limit: int = 100, path: str | Path | None = None) -> list[dict]:
    bounded_limit = max(1, min(int(limit), 500))
    with _connect(path) as connection:
        rows = _execute(connection,
            "SELECT * FROM scans ORDER BY scanned_at DESC, id DESC LIMIT ?",
            (bounded_limit,),
        ).fetchall()
    return [_row_to_scan(row) for row in rows]


def history_for_url(url: str, path: str | Path | None = None) -> list[dict]:
    normalized = sanitize_url_for_storage(url)
    with _connect(path) as connection:
        rows = _execute(connection,
            "SELECT * FROM scans WHERE normalized_url = ? "
            "ORDER BY scanned_at DESC, id DESC",
            (normalized,),
        ).fetchall()
    return [_row_to_scan(row) for row in rows]
