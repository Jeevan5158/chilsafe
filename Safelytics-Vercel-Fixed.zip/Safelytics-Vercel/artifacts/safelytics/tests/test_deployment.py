"""Regressions for the production entry point, CDN paths, and serverless storage."""

from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import importlib
import json
import tempfile

from bs4 import BeautifulSoup
import psycopg
import pytest

from artifacts.safelytics import app as app_module, storage, security, browser

ROOT = Path(__file__).resolve().parents[3]
PAGE = (
    "<html><head><title>School library</title></head><body><h1>Learning resources</h1>"
    "<p>Our school library provides books and helpful learning activities for students "
    "and teachers. Explore science lessons, mathematics, stories and classroom resources "
    "for children and families. This page describes the library and its educational services.</p>"
    "<a href='/privacy'>Privacy policy</a></body></html>"
)


@pytest.fixture
def client(tmp_path):
    return app_module.create_app({
        "TESTING": True, "DATABASE": str(tmp_path / "history.sqlite3"),
    }).test_client()


@pytest.fixture
def fetched_page(monkeypatch):
    monkeypatch.setattr(app_module, "fetch_page", lambda url: {
        "html": PAGE, "final_url": url, "redirect_chain": [], "status_code": 200,
    })


def test_entrypoint_import_never_opens_a_database(monkeypatch):
    def fail(*args, **kwargs):
        raise AssertionError("Database access during application import")
    monkeypatch.setattr(storage, "_connect", fail)
    entry = importlib.import_module("app")
    assert entry.app.test_client().get("/").status_code == 200
    assert entry.app.test_client().get("/api/health").json["status"] == "ok"


@pytest.mark.parametrize("path", ["/", "/history", "/compare", "/learn", "/api/health"])
def test_public_routes_are_available_and_not_cached(client, path):
    response = client.get(path)
    assert response.status_code == 200
    assert response.headers["Cache-Control"] == "no-store"


@pytest.mark.parametrize("url", [
    "/static/style.css", "/static/images/safelytics_logo.svg",
    "/manifest.json", "/service-worker.js",
])
def test_static_urls_match_the_vercel_public_directory(client, url):
    response = client.get(url)
    assert response.status_code == 200
    assert response.data == (ROOT / "public" / url.lstrip("/")).read_bytes()


def test_homepage_assets_and_manifest_are_resolvable(client):
    soup = BeautifulSoup(client.get("/").data, "html.parser")
    urls = [tag.get("src") for tag in soup.select("img[src]")]
    urls += [tag.get("href") for tag in soup.select("link[href]")]
    for url in urls:
        assert client.get(url).status_code == 200, url
    for icon in client.get("/manifest.json").json["icons"]:
        assert client.get(icon["src"]).status_code == 200
    worker = client.get("/service-worker.js")
    assert worker.headers["Service-Worker-Allowed"] == "/"
    assert worker.headers["Cache-Control"] == "no-cache"


def test_vercel_uses_writable_temporary_database(monkeypatch, tmp_path):
    monkeypatch.setenv("VERCEL", "1")
    monkeypatch.delenv("SAFELYTICS_DB_PATH", raising=False)
    monkeypatch.delenv("DATABASE_URL", raising=False)
    assert storage.database_path().is_relative_to(Path(tempfile.gettempdir()))
    assert not storage.database_path().is_relative_to(ROOT)
    monkeypatch.setattr(tempfile, "gettempdir", lambda: str(tmp_path))
    client = app_module.create_app({"TESTING": True}).test_client()
    assert b"history is temporary" in client.get("/").data
    assert client.get("/history").status_code == 200
    assert storage.database_path().exists()


def test_database_url_has_priority_and_is_not_exposed(monkeypatch, tmp_path):
    url = "postgresql://username:secret-value@db.example/database"
    monkeypatch.setenv("DATABASE_URL", url)
    monkeypatch.setenv("VERCEL", "1")
    monkeypatch.setenv("SAFELYTICS_DB_PATH", str(tmp_path / "ignored.sqlite3"))
    app = app_module.create_app({"TESTING": True})
    assert app.config["DATABASE"] == url
    response = app.test_client().get("/api/health")
    assert response.json["storage"] == "postgresql"
    assert response.json["history_temporary"] is False
    assert b"secret-value" not in response.data


def test_postgresql_outage_does_not_break_homepage_or_results(monkeypatch, fetched_page):
    def unavailable(*args, **kwargs):
        raise psycopg.OperationalError("Database unavailable")
    monkeypatch.setattr(psycopg, "connect", unavailable)
    client = app_module.create_app({
        "TESTING": True, "DATABASE": "postgresql://db.example/database",
    }).test_client()
    assert client.get("/").status_code == 200
    result = client.post("/analyze", data={"url": "https://school.example/"})
    assert result.status_code == 200
    assert b"could not be saved" in result.data
    assert b"temporarily unavailable" in client.get("/history").data
    assert client.get("/compare?scan_a=1&scan_b=2").status_code == 200


def test_lazy_sqlite_schema_and_evicted_temp_file_recover(tmp_path):
    path = tmp_path / "evicted.sqlite3"
    assert storage.list_scans(path=path) == []
    path.unlink()
    assert storage.list_scans(path=path) == []


def test_parallel_scan_writes_keep_all_records(tmp_path):
    path = tmp_path / "concurrent.sqlite3"
    def save(index):
        return storage.save_scan({"url": f"https://example.com/{index}"}, path)
    with ThreadPoolExecutor(max_workers=4) as pool:
        ids = list(pool.map(save, range(12)))
    assert len(set(ids)) == 12
    assert len(storage.list_scans(path=path)) == 12


def test_history_comparison_link_requests_another_scan(client, fetched_page):
    client.post("/analyze", data={"url": "school.example"})
    soup = BeautifulSoup(client.get("/history").data, "html.parser")
    link = soup.select_one(".history-detail a")
    assert "scan_a=" in link["href"]
    assert "scan_b=" not in link["href"]


def test_oversized_comparison_ids_have_friendly_validation(client):
    response = client.get(f"/compare?scan_a={2**100}&scan_b=1")
    assert response.status_code == 200
    assert b"Choose two valid scans" in response.data


def test_serverless_browser_fallback_stays_disabled(monkeypatch):
    monkeypatch.setenv("VERCEL", "1")
    monkeypatch.setenv("SAFELYTICS_ENABLE_BROWSER", "1")
    assert browser.is_browser_fallback_enabled() is False


def test_fetch_budget_stops_redirect_chain(monkeypatch):
    from test_safelytics import FakeResponse, FakeSession, public_resolver
    session = FakeSession([FakeResponse(302, headers={"Location": "https://example.com/next"})])
    clock = iter([0, 0, 0, 26])
    monkeypatch.setattr(security.time, "monotonic", lambda: next(clock))
    monkeypatch.setattr(security.requests, "Session", lambda: session)
    with pytest.raises(security.FetchFailure, match="total scan time budget"):
        security.fetch_page("https://example.com/", resolver=public_resolver)
    assert len(session.calls) == 1
    assert session.closed


def test_fetch_budget_stops_streaming_body(monkeypatch):
    from test_safelytics import FakeResponse, FakeSession, public_resolver
    response = FakeResponse(200)
    session = FakeSession([response])
    clock = iter([0, 0, 0, 26])
    monkeypatch.setattr(security.time, "monotonic", lambda: next(clock))
    monkeypatch.setattr(security.requests, "Session", lambda: session)
    with pytest.raises(security.FetchFailure, match="total scan time budget"):
        security.fetch_page("https://example.com/", resolver=public_resolver)
    assert response.closed and session.closed


def test_unsupported_database_scheme_is_rejected():
    with pytest.raises(ValueError, match="PostgreSQL"):
        storage.initialize_database("mysql://database.example/app")


def test_deployment_configuration_targets_flask():
    config = json.loads((ROOT / "vercel.json").read_text())
    assert config["framework"] == "flask"
    assert config["functions"]["app.py"]["maxDuration"] >= 60
    assert not (ROOT / "package.json").exists()
