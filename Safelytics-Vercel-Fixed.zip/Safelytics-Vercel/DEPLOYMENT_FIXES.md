# Deployment review and fixes

Reviewed the supplied `Safelytics-Safety-Analyzer (2).zip` on 18 November 2026. No Vercel account settings or failed deployment logs were supplied; the findings below come from the source archive and local verification.

## Findings

| Original problem | Impact | Fix |
| --- | --- | --- |
| Root Node workspace did not describe the working Flask application | A normal import could build unused Replit artifacts instead of the analyzer | Deployment package contains the actual Flask frontend/backend and a Flask framework configuration |
| `package.json` preinstall explicitly rejected npm and required pnpm | An npm installation fails immediately | Removed the unused Node build path from the deployment package |
| The workspace build traversed `artifacts/mockup-sandbox`; its Vite config required `PORT` and `BASE_PATH` | Build fails when those Replit-specific variables are absent | Excluded the unused mockup, empty Express health API and generated client/database scaffolds |
| Root `main.py` only printed a greeting; the real app was nested in `artifacts/safelytics/app.py` | No conventional root Flask export for Vercel | Added root `app.py` exporting the existing Flask application |
| No Vercel-specific runtime configuration | Runtime/framework selection and routing were ambiguous | Added `vercel.json`, a Python 3.12 selector and a 60-second function limit |
| Python dependency manifests were inconsistent and mixed runtime with test/server tools | Build environment depended on which manifest was selected | One runtime dependency list; separate development requirements |
| Styles, logo and PWA files lived only inside the Flask package | Incompatible with Vercel's recommended public-asset layout | Moved assets into `public/`; retained matching Flask routes for local use |
| SQLite defaulted to a source-tree `instance/` directory | Vercel's read-only filesystem prevents history writes; the original code catches this and disables history | Writable `/tmp` fallback on Vercel, with explicit temporary-history notice |
| SQLite alone cannot provide shared, durable serverless history | History may vanish or differ between function instances | Added optional PostgreSQL via `DATABASE_URL`; no credentials required for the analyzer itself |
| SQLite connection context managers did not close their connections | Reused workers could retain resources and locks | Connections now commit/rollback and close explicitly |
| Database schema initialization ran during app import | Startup performed unnecessary writable-filesystem/database work | Initialize storage lazily on data operations, with graceful failure handling |
| Fetch timeouts applied per request, with multiple redirects and streamed reads | Slow targets could keep a serverless request running too long | Added a 25-second elapsed-time budget checked between redirect hops and chunks; individual blocking calls can extend elapsed time |
| A history link supplied the same ID as both comparison selections | Following the link immediately produced a same-scan validation error | Preselect only the first scan; let the user choose the second |
| Form validation handled uppercase URL schemes incorrectly and had no submission state | Valid addresses could be rejected; repeated clicks were easy | Case-insensitive scheme parsing, explicit HTTP(S) checks, loading button and Back-button reset |
| Optional browser fallback depended on locally installed browser binaries | Those binaries are not part of this serverless package | Explicitly disable the optional fallback on Vercel |
| Archive included Git internals, generated bundles, cached Python files and local scan databases | Unnecessary deployment size and accidental exposure of development/history data | Package only application source, public assets, fixtures, tests and deployment documentation |

The scoring algorithm, existing findings, quizzes and primary visual design are preserved. This is a deployment-focused repair, not a rewrite as React or a change to the risk scale.

## Verification

- Original baseline: **46 tests passed** before changes.
- Updated automated suite: **69 tests passed**, including the original analysis/extraction tests and new deployment regressions.
- Route and asset checks cover `/`, `/analyze`, `/history`, `/compare`, `/learn`, `/api/health`, the CSS, logo, manifest and service worker.
- New regressions cover temporary storage, concurrent writes, temporary-file recovery, failed PostgreSQL connections, no database access on import, safe health responses, comparison IDs and total fetch budgets.
- Frontend JavaScript executed in JSDOM with eight valid/invalid URL cases, error-modal display, loading state and Back-navigation reset. No JavaScript errors were observed.
- The official `@vercel/python` 32.1.0 builder packaged the app as a Python 3.12 function with a 60-second maximum duration. The package contains the application templates and runtime dependencies and excludes the application's tests and local database. The public assets were checked separately, as Vercel serves them outside the function. This is not a deployment to a Vercel account or a full authenticated Vercel CLI build.
- The resulting function bundle was imported using its own packaged dependencies and smoke-tested for page rendering, two scans, saved history and comparison. The function bundle is approximately 20 MB uncompressed.
- PostgreSQL failure handling was tested with a simulated unavailable server. A live hosted PostgreSQL connection was not available for end-to-end persistence testing.
- A full visual browser run was unavailable because the local browser process was blocked by the execution environment. Template, route, asset and JavaScript behavior were checked separately.

No production deployment was made. After importing the package, verify the deployed health endpoint and perform a scan. If configuring PostgreSQL, also confirm that the scan appears in history after redeployment.
