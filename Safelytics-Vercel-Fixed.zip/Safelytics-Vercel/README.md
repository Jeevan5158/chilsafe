# Safelytics — Vercel deployment

This package contains the working Safelytics frontend and backend in one Flask application. The frontend uses HTML/Jinja templates, CSS and JavaScript. The backend performs the website analysis, handles forms and quizzes, and stores scan history. A separate React/Node deployment is not needed.

## Deploy to Vercel

1. Unzip the download. Open the **Safelytics-Vercel** folder.
2. Put this folder's **contents** in a GitHub repository. `app.py`, `vercel.json`, `requirements.txt`, `.python-version`, `public/` and `artifacts/` must be together at the repository root. Vercel imports the repository, not the ZIP file itself.
3. In Vercel, select **Add New → Project**, then import that repository.
4. Use the settings below. For an existing Vercel project, remove its previous npm/pnpm build, install and output overrides first.
5. Deploy. After deployment, open `/api/health`, then try a scan, the History page and the Safety learning quiz.

| Setting | Value |
| --- | --- |
| Framework Preset | Flask |
| Root Directory | The folder containing `app.py` and `vercel.json`; `.` if they are at the repository root |
| Build Command | No override / unset |
| Install Command | No override; Python dependencies come from `requirements.txt` |
| Output Directory | No override / unset; do not enter `dist`, `build` or `public` |
| Python | 3.12, selected by the included `.python-version` |
| Required environment variables for analysis | None |
| Optional environment variable for durable history | `DATABASE_URL`, with a PostgreSQL connection string |

If reusing your old GitHub repository, replace the old project contents with this package. Do not leave the old `package.json`, `pnpm-lock.yaml`, `pnpm-workspace.yaml`, `pyproject.toml`, Replit configuration, or unused mockup/API scaffold alongside it. Those files describe a different build system. Keep this package's source structure intact.

The Vercel function handles `/`, `/analyze`, `/history`, `/compare`, `/learn` and `/api/health`. Files inside `public/` use the same public URLs on Vercel and during local development. The function's maximum duration is configured as 60 seconds. No production `app.run()` or Gunicorn process is needed on Vercel.

## Persistent scan history

Website analysis works without a database account or AI API key.

On Vercel, the default SQLite database lives under `/tmp/safelytics/`. This is **temporary, instance-local storage**. Records can disappear after a restart, redeployment or instance change, and different instances can show different histories. The website displays a notice in this mode. Pointing `SAFELYTICS_DB_PATH` at `/tmp` does not make it persistent.

For history and comparisons that survive deployments:

1. Create a hosted PostgreSQL database reachable from Vercel.
2. Copy its standard PostgreSQL connection string, including the provider's required SSL settings.
3. Add it as **DATABASE_URL** in Vercel's Project Settings → Environment Variables, for the environments you intend to use.
4. Redeploy, then run a scan. The app creates its `scans` table and index on the first database request. The database user needs permission to create these objects.

Example format, with placeholders only:

```text
postgresql://USER:PASSWORD@HOST:5432/DATABASE?sslmode=require
```

Do not commit the real URL or password. The app reads environment variables; copying `.env.example` to `.env` does not load it automatically. Use Vercel settings or export variables in your terminal.

An unreachable database does not stop the homepage, quizzes or scan results from working. Results display a warning if saving fails. `/api/health` checks that the application is running and reports the configured storage mode; it does not test database connectivity. Confirm storage by saving and viewing a scan.

History remains **shared with everyone who can access this app**, as in the original project. Only scan public URLs. There are no user accounts or private per-user histories, and only common secret-like query parameters are redacted. Do not submit password-reset links, private tokens or confidential URLs.

## Run locally on your Mac

Open Terminal in the extracted `Safelytics-Vercel` folder:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python app.py
```

Open **http://localhost:5004**. Port 5004 avoids the common macOS AirPlay conflict on port 5000. If 5004 is occupied, use `PORT=5050 python app.py` instead.

Outside Vercel, history uses `artifacts/safelytics/instance/safelytics.sqlite3`, created on demand. `SAFELYTICS_DB_PATH` can select another writable local path. `DATABASE_URL` takes priority over SQLite settings.

## Tests

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q artifacts/safelytics/tests
python -m artifacts.safelytics.evaluation
```

The evaluation uses a small synthetic fixture set, not a real-world accuracy benchmark. See `DEPLOYMENT_FIXES.md` for the changes and validation scope.

## Project layout

| Path | Purpose |
| --- | --- |
| `app.py` | Vercel WSGI entry point and local launcher |
| `vercel.json` | Flask framework, function settings and response headers |
| `requirements.txt` | Runtime Python dependencies |
| `public/static/` | CSS and logo, served from `/static/...` |
| `public/manifest.json`, `public/service-worker.js` | Install metadata and service worker |
| `artifacts/safelytics/templates/` | Frontend pages |
| `artifacts/safelytics/app.py` | Routes and scan workflow |
| `artifacts/safelytics/analysis.py` | Existing rule-based scoring and findings |
| `artifacts/safelytics/security.py` | Public URL validation and bounded fetching |
| `artifacts/safelytics/storage.py` | PostgreSQL / SQLite storage |
| `artifacts/safelytics/tests/` | Analysis, UI route and deployment regression tests |

## Analysis limits

The original explainable scoring rules are preserved: this is a **risk score from 0 to 10, with higher meaning greater risk**. It is not an ML model or a guarantee of safety. Failed downloads and unavailable content checks are shown as unavailable/partial, not as fabricated clean content.

The Vercel deployment reads static HTML. JavaScript-only pages, login pages and sites that block automated access may be unscannable; deploying successfully cannot remove those restrictions. Optional local headless-browser rendering is disabled on Vercel. The fetcher checks its elapsed-time budget between redirects and streamed chunks; DNS and individual blocking I/O calls are also subject to their underlying platform limits.

This website analyzes submitted URLs. It does not block websites across a child's browser or device.

## Official deployment references

- https://vercel.com/docs/frameworks/backend/flask
- https://vercel.com/docs/functions/runtimes/python
- https://vercel.com/docs/functions/runtimes
