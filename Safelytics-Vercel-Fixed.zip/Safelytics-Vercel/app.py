"""WSGI entry point detected by Vercel's Flask runtime."""

import os

from artifacts.safelytics.app import app


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5004")), debug=False)
